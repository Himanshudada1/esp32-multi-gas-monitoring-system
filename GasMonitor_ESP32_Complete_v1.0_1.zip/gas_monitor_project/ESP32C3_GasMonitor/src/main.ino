/*
 * ============================================================
 *  IoT-Based Multi-Gas Monitoring System
 *  Hardware: XIAO ESP32C3 + MQ2 + MQ3 + MQ5 + MQ9 Sensors
 *  Author  : Your Name
 *  Version : 1.0
 *  Date    : 2026-01-20
 * ============================================================
 */

#include <WiFi.h>
#include <WebServer.h>
#include <ArduinoJson.h>
#include "config.h"

// ─── Pin Definitions ───────────────────────────────────────
#define MQ2_PIN   D0   // Smoke, LPG, Hydrogen
#define MQ3_PIN   D1   // Alcohol, Ethanol
#define MQ5_PIN   D2   // LPG, Natural Gas
#define MQ9_PIN   D3   // Carbon Monoxide
#define LED_PIN   D4   // LED Alert (via ZTX450STZ transistor)

// ─── Threshold Values (0-4095 ADC) ────────────────────────
#define MQ2_THRESHOLD  1500
#define MQ3_THRESHOLD  1200
#define MQ5_THRESHOLD  1300
#define MQ9_THRESHOLD  1400

// ─── Global Variables ──────────────────────────────────────
WebServer server(80);

int mq2Value = 0;
int mq3Value = 0;
int mq5Value = 0;
int mq9Value = 0;
bool alertActive = false;

// ─── WiFi Connect ──────────────────────────────────────────
void connectWiFi() {
  Serial.print("Connecting to WiFi: ");
  Serial.println(WIFI_SSID);
  WiFi.begin(WIFI_SSID, WIFI_PASS);
  int attempts = 0;
  while (WiFi.status() != WL_CONNECTED && attempts < 20) {
    delay(500);
    Serial.print(".");
    attempts++;
  }
  if (WiFi.status() == WL_CONNECTED) {
    Serial.println("\nWiFi Connected!");
    Serial.print("IP Address: ");
    Serial.println(WiFi.localIP());
  } else {
    Serial.println("\nWiFi Failed! Running offline.");
  }
}

// ─── Read All Sensors ──────────────────────────────────────
void readSensors() {
  mq2Value = analogRead(MQ2_PIN);
  delay(10);
  mq3Value = analogRead(MQ3_PIN);
  delay(10);
  mq5Value = analogRead(MQ5_PIN);
  delay(10);
  mq9Value = analogRead(MQ9_PIN);
  delay(10);
}

// ─── Check Alert Condition ─────────────────────────────────
void checkAlert() {
  if (mq2Value > MQ2_THRESHOLD ||
      mq3Value > MQ3_THRESHOLD ||
      mq5Value > MQ5_THRESHOLD ||
      mq9Value > MQ9_THRESHOLD) {
    alertActive = true;
    digitalWrite(LED_PIN, HIGH);
    Serial.println("⚠️  GAS ALERT DETECTED!");
  } else {
    alertActive = false;
    digitalWrite(LED_PIN, LOW);
  }
}

// ─── Print to Serial Monitor ───────────────────────────────
void printSerial() {
  Serial.println("─────────────────────────────");
  Serial.print("MQ2 (Smoke/LPG)    : "); Serial.println(mq2Value);
  Serial.print("MQ3 (Alcohol)      : "); Serial.println(mq3Value);
  Serial.print("MQ5 (Natural Gas)  : "); Serial.println(mq5Value);
  Serial.print("MQ9 (CO)           : "); Serial.println(mq9Value);
  Serial.print("Alert Status       : "); Serial.println(alertActive ? "DANGER ⚠️" : "SAFE ✅");
  Serial.println("─────────────────────────────");
}

// ─── Web Server: Main Dashboard ────────────────────────────
void handleRoot() {
  String html = "<!DOCTYPE html><html><head>";
  html += "<meta charset='UTF-8'>";
  html += "<meta name='viewport' content='width=device-width, initial-scale=1'>";
  html += "<meta http-equiv='refresh' content='3'>";
  html += "<title>Gas Monitor</title>";
  html += "<style>";
  html += "body{font-family:Arial,sans-serif;background:#1a1a2e;color:#fff;margin:0;padding:20px;}";
  html += "h1{text-align:center;color:#00d4ff;}";
  html += ".grid{display:grid;grid-template-columns:repeat(2,1fr);gap:15px;max-width:600px;margin:auto;}";
  html += ".card{background:#16213e;border-radius:12px;padding:20px;text-align:center;border:1px solid #0f3460;}";
  html += ".value{font-size:2em;font-weight:bold;color:#00d4ff;}";
  html += ".label{font-size:0.9em;color:#aaa;margin-top:5px;}";
  html += ".safe{color:#00ff88;}.danger{color:#ff4444;}";
  html += ".alert-box{max-width:600px;margin:15px auto;padding:15px;border-radius:12px;text-align:center;font-size:1.2em;font-weight:bold;}";
  html += ".alert-safe{background:#003300;color:#00ff88;border:1px solid #00ff88;}";
  html += ".alert-danger{background:#330000;color:#ff4444;border:1px solid #ff4444;animation:blink 1s infinite;}";
  html += "@keyframes blink{0%,100%{opacity:1;}50%{opacity:0.5;}}";
  html += "</style></head><body>";
  html += "<h1>🌡️ Multi-Gas Monitor</h1>";
  
  // Alert Box
  if (alertActive) {
    html += "<div class='alert-box alert-danger'>⚠️ HAZARDOUS GAS DETECTED!</div>";
  } else {
    html += "<div class='alert-box alert-safe'>✅ AIR QUALITY: SAFE</div>";
  }

  // Sensor Cards
  html += "<div class='grid'>";
  html += "<div class='card'><div class='value " + String(mq2Value > MQ2_THRESHOLD ? "danger" : "safe") + "'>" + String(mq2Value) + "</div><div class='label'>MQ2<br>Smoke / LPG</div></div>";
  html += "<div class='card'><div class='value " + String(mq3Value > MQ3_THRESHOLD ? "danger" : "safe") + "'>" + String(mq3Value) + "</div><div class='label'>MQ3<br>Alcohol / Ethanol</div></div>";
  html += "<div class='card'><div class='value " + String(mq5Value > MQ5_THRESHOLD ? "danger" : "safe") + "'>" + String(mq5Value) + "</div><div class='label'>MQ5<br>Natural Gas / LPG</div></div>";
  html += "<div class='card'><div class='value " + String(mq9Value > MQ9_THRESHOLD ? "danger" : "safe") + "'>" + String(mq9Value) + "</div><div class='label'>MQ9<br>Carbon Monoxide</div></div>";
  html += "</div>";

  // Camera Link
  html += "<div style='text-align:center;margin-top:20px;'>";
  html += "<a href='http://" + String(CAM_IP) + "' style='color:#00d4ff;'>📷 View Camera Feed</a>";
  html += "</div>";

  html += "</body></html>";
  server.send(200, "text/html", html);
}

// ─── Web Server: JSON API ──────────────────────────────────
void handleData() {
  StaticJsonDocument<200> doc;
  doc["mq2"] = mq2Value;
  doc["mq3"] = mq3Value;
  doc["mq5"] = mq5Value;
  doc["mq9"] = mq9Value;
  doc["alert"] = alertActive;
  doc["status"] = alertActive ? "DANGER" : "SAFE";

  String output;
  serializeJson(doc, output);
  server.send(200, "application/json", output);
}

// ─── Setup ─────────────────────────────────────────────────
void setup() {
  Serial.begin(115200);
  delay(1000);

  Serial.println("=== Multi-Gas Monitor Booting ===");

  // Pin setup
  pinMode(LED_PIN, OUTPUT);
  digitalWrite(LED_PIN, LOW);

  // ADC setup
  analogReadResolution(12); // 12-bit = 0-4095

  // Sensor warmup
  Serial.println("Warming up sensors (30 sec)...");
  for (int i = 30; i > 0; i--) {
    Serial.print(i); Serial.print("... ");
    delay(1000);
  }
  Serial.println("\nSensors ready!");

  // WiFi
  connectWiFi();

  // Web server routes
  server.on("/", handleRoot);
  server.on("/data", handleData);
  server.begin();
  Serial.println("Web server started!");
  Serial.print("Dashboard: http://");
  Serial.println(WiFi.localIP());
}

// ─── Loop ──────────────────────────────────────────────────
void loop() {
  server.handleClient();
  readSensors();
  checkAlert();
  printSerial();
  delay(2000);
}
