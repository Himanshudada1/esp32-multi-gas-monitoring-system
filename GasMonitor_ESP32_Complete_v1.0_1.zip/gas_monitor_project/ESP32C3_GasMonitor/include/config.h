/*
 * config.h — WiFi & System Configuration
 * Change these values before uploading!
 */

#ifndef CONFIG_H
#define CONFIG_H

// ─── WiFi Settings ─────────────────────────────────────────
#define WIFI_SSID   "Your_WiFi_Name"      // Apna WiFi name
#define WIFI_PASS   "Your_WiFi_Password"  // Apna WiFi password

// ─── ESP32-CAM IP ──────────────────────────────────────────
// ESP32-CAM ka IP address yahan likhein (serial monitor se milega)
#define CAM_IP      "192.168.1.101"

// ─── System Settings ───────────────────────────────────────
#define SENSOR_READ_INTERVAL  2000   // ms - kitni baar sensor padhein
#define SERIAL_BAUD           115200

#endif
