# IoT-Based Multi-Gas Monitoring System with ESP32-CAM

![License](https://img.shields.io/badge/License-CERN--OHL--S-blue)
![Platform](https://img.shields.io/badge/Platform-ESP32-green)
![Version](https://img.shields.io/badge/Version-1.0-orange)
![Status](https://img.shields.io/badge/Status-Active-brightgreen)

An open-source IoT project for real-time detection of multiple hazardous gases using XIAO ESP32C3 and ESP32-CAM. Built with a custom PCB designed in EasyEDA, this system simultaneously monitors LPG, smoke, alcohol, carbon monoxide, and natural gas — with live camera surveillance and a web-based dashboard.

---

## 📸 Project Preview

| PCB 3D View | Hardware |
|-------------|----------|
| ![PCB](images/3d_view.jpg) | ![Hardware](images/hardware.jpg) |

---

## ✨ Features

- ✅ 4-channel simultaneous gas monitoring (MQ2, MQ3, MQ5, MQ9)
- ✅ Live video streaming via ESP32-CAM
- ✅ Real-time web dashboard with auto-refresh
- ✅ JSON API for external integrations
- ✅ LED alert system via ZTX450STZ transistor driver
- ✅ Custom PCB with Grove-compatible connectors
- ✅ WiFi-enabled wireless monitoring
- ✅ Open-source hardware and firmware

---

## 🔬 Gas Sensors

| Sensor | Detects | Threshold |
|--------|---------|-----------|
| **MQ2** | LPG, Smoke, Hydrogen | 1500 |
| **MQ3** | Alcohol, Ethanol | 1200 |
| **MQ5** | LPG, Natural Gas | 1300 |
| **MQ9** | Carbon Monoxide | 1400 |

---

## ⚙️ Hardware Components

| Component | Quantity |
|-----------|----------|
| XIAO ESP32C3 | 1 |
| ESP32-CAM (AI-Thinker) | 1 |
| MQ2 Gas Sensor (Grove) | 1 |
| MQ3 Gas Sensor (Grove) | 1 |
| MQ5 Gas Sensor (Grove) | 1 |
| MQ9 Gas Sensor (Grove) | 1 |
| LED 3mm | 4 |
| Resistor 330Ω | 4 |
| Resistor 1KΩ | 1 |
| ZTX450STZ NPN Transistor | 1 |
| Custom PCB (EasyEDA) | 1 |

---

## 📁 Project Structure

```
esp32-multi-gas-monitoring-system/
│
├── ESP32C3_GasMonitor/
│   ├── src/
│   │   └── main.ino              ← Upload to XIAO ESP32C3
│   └── include/
│       └── config.h              ← WiFi credentials here
│
├── ESP32CAM_Stream/
│   └── src/
│       └── ESP32CAM_Stream.ino   ← Upload to ESP32-CAM
│
├── images/                       ← Project photos
├── schematic/                    ← EasyEDA schematic files
└── README.md
```

---

## 🔌 Pin Connections (XIAO ESP32C3)

| Pin | Connected To |
|-----|-------------|
| D0 | MQ2 Analog Out |
| D1 | MQ3 Analog Out |
| D2 | MQ5 Analog Out |
| D3 | MQ9 Analog Out |
| D4 | LED Driver (ZTX450STZ Base) |
| 5V | Sensor VCC |
| GND | Common Ground |

---

## 🚀 Getting Started

### Step 1 — Arduino IDE Setup
1. Download [Arduino IDE 2.x](https://www.arduino.cc/en/software)
2. Go to **File → Preferences → Additional Board URLs** and add:
```
https://raw.githubusercontent.com/espressif/arduino-esp32/gh-pages/package_esp32_index.json
```
3. Go to **Tools → Board Manager** → Search "esp32" → Install

### Step 2 — Install Libraries
Install from **Library Manager**:
- `ArduinoJson` by Benoit Blanchon

### Step 3 — Configure WiFi
Edit `ESP32C3_GasMonitor/include/config.h`:
```cpp
#define WIFI_SSID  "Your_WiFi_Name"
#define WIFI_PASS  "Your_WiFi_Password"
#define CAM_IP     "192.168.1.xxx"   // ESP32-CAM IP
```

### Step 4 — Upload to XIAO ESP32C3
1. Select Board: **XIAO_ESP32C3**
2. Open `ESP32C3_GasMonitor/src/main.ino`
3. Upload and open Serial Monitor
4. Note the IP address shown

### Step 5 — Upload to ESP32-CAM
1. Connect **GPIO0 → GND** (upload mode)
2. Select Board: **AI Thinker ESP32-CAM**
3. Open `ESP32CAM_Stream/src/ESP32CAM_Stream.ino`
4. Update WiFi credentials
5. Upload → Remove GPIO0-GND → Press Reset
6. Note Camera IP from Serial Monitor

---

## 🌐 Web Dashboard

Open browser and go to:
```
http://<ESP32C3_IP_ADDRESS>
```

**Dashboard Features:**
- Real-time sensor readings
- SAFE / DANGER status indicator
- Auto-refresh every 3 seconds
- Direct camera feed link

**JSON API Endpoint:**
```
http://<ESP32C3_IP_ADDRESS>/data
```

Sample response:
```json
{
  "mq2": 320,
  "mq3": 210,
  "mq5": 180,
  "mq9": 290,
  "alert": false,
  "status": "SAFE"
}
```

---

## 📐 PCB Design

- Designed using **EasyEDA**
- Schematic REV: 1.0 (2026-01-20)
- Grove-standard XH2.54-4PIN connectors
- On-board LED indicators
- Compact single-board design
- 5V powered system

---

## 🔧 Customization

Change gas thresholds in `main.ino`:
```cpp
#define MQ2_THRESHOLD  1500   // Increase = less sensitive
#define MQ3_THRESHOLD  1200
#define MQ5_THRESHOLD  1300
#define MQ9_THRESHOLD  1400
```

Change camera resolution in `ESP32CAM_Stream.ino`:
```cpp
config.frame_size = FRAMESIZE_VGA;     // 640x480
// config.frame_size = FRAMESIZE_SVGA; // 800x600
// config.frame_size = FRAMESIZE_XGA;  // 1024x768
```

---

## 🤝 Contributing

This project was developed with support from an experienced **Embedded Software Development Company** specializing in IoT and embedded systems. Contributions, improvements, and forks are welcome!

1. Fork this repository
2. Create your feature branch (`git checkout -b feature/NewFeature`)
3. Commit your changes (`git commit -m 'Add NewFeature'`)
4. Push to the branch (`git push origin feature/NewFeature`)
5. Open a Pull Request

---

## 📜 License

This project is released under the **CERN Open Hardware Licence v2 (CERN-OHL-S)**.
You are free to study, modify, distribute, and build upon this design.

---

## 🏷️ Tags

`ESP32` `ESP32-CAM` `IoT` `Gas Sensor` `MQ2` `MQ3` `MQ5` `MQ9` `Air Quality` `PCB Design` `EasyEDA` `Arduino` `Embedded Systems` `Open Source Hardware` `Safety Monitor` `Environmental Monitoring`
