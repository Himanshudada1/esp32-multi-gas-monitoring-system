# IoT-Based Multi-Gas Monitoring System with ESP32-CAM
## Version 1.0 | Date: 2026-01-20

---

## 📁 Project Structure

```
gas_monitor_project/
│
├── ESP32C3_GasMonitor/          ← Main gas monitoring code
│   ├── src/
│   │   └── main.ino             ← Upload to XIAO ESP32C3
│   └── include/
│       └── config.h             ← WiFi settings here
│
├── ESP32CAM_Stream/             ← Camera streaming code
│   └── src/
│       └── ESP32CAM_Stream.ino  ← Upload to ESP32-CAM
│
└── README.md                    ← This file
```

---

## ⚙️ Hardware Required

| Component         | Quantity |
|-------------------|----------|
| XIAO ESP32C3      | 1        |
| ESP32-CAM         | 1        |
| MQ2 Gas Sensor    | 1        |
| MQ3 Gas Sensor    | 1        |
| MQ5 Gas Sensor    | 1        |
| MQ9 Gas Sensor    | 1        |
| LED 3mm           | 4        |
| Resistor 330Ω     | 4        |
| Resistor 1KΩ      | 1        |
| ZTX450STZ (NPN)   | 1        |
| Custom PCB        | 1        |

---

## 🔌 Pin Connections (XIAO ESP32C3)

| Pin | Sensor       |
|-----|--------------|
| D0  | MQ2 Analog   |
| D1  | MQ3 Analog   |
| D2  | MQ5 Analog   |
| D3  | MQ9 Analog   |
| D4  | LED (via transistor) |

---

## 🚀 Setup Instructions

### Step 1 — Arduino IDE Setup
1. Arduino IDE install karein (v2.x recommended)
2. File → Preferences → Additional Board URLs mein add karein:
   ```
   https://raw.githubusercontent.com/espressif/arduino-esp32/gh-pages/package_esp32_index.json
   ```
3. Tools → Board Manager → "esp32" install karein

### Step 2 — Libraries Install
Arduino IDE mein Library Manager se install karein:
- `ArduinoJson` by Benoit Blanchon

### Step 3 — Config Setup
`ESP32C3_GasMonitor/include/config.h` file mein:
```cpp
#define WIFI_SSID  "Apna_WiFi_Naam"
#define WIFI_PASS  "Apna_Password"
```

### Step 4 — Upload ESP32C3 Code
1. Board: **XIAO_ESP32C3** select karein
2. `ESP32C3_GasMonitor/src/main.ino` open karein
3. Upload karein
4. Serial Monitor mein IP address note karein

### Step 5 — Upload ESP32-CAM Code
1. Board: **AI Thinker ESP32-CAM** select karein
2. GPIO0 ko GND se connect karein (upload mode)
3. `ESP32CAM_Stream/src/ESP32CAM_Stream.ino` open karein
4. WiFi credentials update karein
5. Upload karein
6. GPIO0-GND wire hatao → Reset dabao
7. Serial Monitor mein Camera IP note karein

### Step 6 — Update Camera IP
`config.h` mein Camera IP update karein:
```cpp
#define CAM_IP  "192.168.1.xxx"  // ESP32-CAM ka IP
```
Aur ESP32C3 code dobara upload karein.

---

## 🌐 Web Dashboard

Browser mein ESP32C3 ka IP open karein:
```
http://192.168.1.xxx
```

Features:
- ✅ Real-time gas sensor values
- ✅ SAFE / DANGER status
- ✅ Auto-refresh every 3 seconds
- ✅ Camera feed link

JSON API:
```
http://192.168.1.xxx/data
```

---

## ⚠️ Gas Threshold Values

| Sensor | Default Threshold | Detects |
|--------|------------------|---------|
| MQ2    | 1500             | Smoke, LPG, H2 |
| MQ3    | 1200             | Alcohol, Ethanol |
| MQ5    | 1300             | LPG, Natural Gas |
| MQ9    | 1400             | CO, Flammable Gas |

Threshold change karne ke liye `main.ino` mein:
```cpp
#define MQ2_THRESHOLD  1500  // Yeh value change karein
```

---

## 📜 License
CERN Open Hardware Licence v2 (CERN-OHL-S)
Open source — freely use, modify, and distribute!
